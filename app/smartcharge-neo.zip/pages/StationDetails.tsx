import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Share2, AlertTriangle, MapPin, Zap, Activity, Thermometer, Calendar, Clock, ArrowRight, BatteryCharging, Plug, CheckCircle } from 'lucide-react';
import { HOURLY_POWER_DATA, WEEKLY_POWER_DATA } from '../constants';
import { BarChart, Bar, ResponsiveContainer, Cell, XAxis, Tooltip } from 'recharts';

const SensorCard = ({ title, value, unit, icon: Icon, color, percent }: any) => (
  <div className="flex flex-col gap-3 rounded-xl p-5 bg-surface-dark border border-border-dark relative overflow-hidden group hover:border-primary/50 transition-colors">
    <div className="absolute top-0 right-0 p-3 opacity-10 group-hover:opacity-20 transition-opacity">
      <Icon size={40} />
    </div>
    <p className="text-text-secondary text-sm font-medium">{title}</p>
    <div className="flex items-baseline gap-1">
      <p className="text-white text-2xl font-bold font-display tracking-tight">{value}</p>
      <span className="text-xs text-text-secondary">{unit}</span>
    </div>
    <div className="w-full h-1 bg-bg-dark rounded-full overflow-hidden mt-1">
      <div className={`h-full rounded-full ${color}`} style={{ width: `${percent}%` }}></div>
    </div>
  </div>
);

const StationDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [chartView, setChartView] = useState<'24h' | '7d'>('24h');
  const [isBooked, setIsBooked] = useState(false);
  const [isBooking, setIsBooking] = useState(false);
  const [selectedDuration, setSelectedDuration] = useState('1h');
  const [bookingTime, setBookingTime] = useState('16:00');

  const chartData = chartView === '24h' ? HOURLY_POWER_DATA : WEEKLY_POWER_DATA;

  const handleBooking = () => {
    setIsBooking(true);
    setTimeout(() => {
        setIsBooking(false);
        setIsBooked(true);
    }, 1500);
  };

  return (
    <div className="h-full overflow-y-auto scrollbar-hide">
        {/* Top Header */}
        <header className="sticky top-0 z-40 bg-bg-dark/95 backdrop-blur-sm border-b border-border-dark px-6 lg:px-10 py-4 flex items-center justify-between">
           <div className="flex items-center gap-2 text-sm text-text-secondary">
               <span onClick={() => navigate('/')} className="hover:text-white cursor-pointer">Home</span>
               <span>/</span>
               <span onClick={() => navigate('/map')} className="hover:text-white cursor-pointer">Stations</span>
               <span>/</span>
               <span className="text-white">Station Details</span>
           </div>
           <div className="flex gap-3">
               <button className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-surface-dark border border-border-dark text-white text-sm hover:bg-surface-lighter transition-colors">
                   <Share2 size={16} /> Share
               </button>
               <button className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-surface-dark border border-border-dark text-rose-400 text-sm hover:bg-surface-lighter transition-colors">
                   <AlertTriangle size={16} /> Report
               </button>
           </div>
        </header>

        <main className="max-w-7xl mx-auto px-6 lg:px-10 py-8 flex flex-col gap-8">
            
            {/* Title Section */}
            <div className="flex flex-col gap-2">
                <div className="flex items-center gap-4">
                    <h1 className="text-white text-3xl md:text-4xl font-bold font-display tracking-tight">Station République B2</h1>
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                        <span className="size-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                        Operational
                    </span>
                </div>
                <p className="text-text-secondary flex items-center gap-2">
                    <MapPin size={16} />
                    12 Av. de la République, 75011 Paris
                </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 md:gap-8">
                {/* Left Column (8 cols) */}
                <div className="lg:col-span-8 flex flex-col gap-6">
                    {/* Sensors */}
                    <section>
                         <div className="flex justify-between items-center mb-4">
                            <h3 className="text-lg font-bold text-white flex items-center gap-2">
                                <Activity className="text-primary" size={20} />
                                Real-time Sensor Data
                            </h3>
                            <span className="text-xs text-emerald-400 flex items-center gap-1">
                                <span className="size-1.5 bg-emerald-500 rounded-full animate-pulse"></span> Live
                            </span>
                         </div>
                         <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                             <SensorCard title="Voltage" value="230.1" unit="V" icon={Zap} color="bg-primary" percent={90} />
                             <SensorCard title="Current" value="31.5" unit="A" icon={Activity} color="bg-cyan-400" percent={60} />
                             <SensorCard title="Output" value="7.2" unit="kW" icon={BatteryCharging} color="bg-purple-400" percent={75} />
                             <SensorCard title="Temp" value="42" unit="°C" icon={Thermometer} color="bg-emerald-400" percent={40} />
                         </div>
                    </section>

                    {/* Chart */}
                    <section className="bg-surface-dark rounded-xl border border-border-dark p-6">
                         <div className="flex justify-between items-center mb-6">
                            <h3 className="text-lg font-bold text-white">Power Output History</h3>
                            <select 
                                value={chartView}
                                onChange={(e) => setChartView(e.target.value as '24h' | '7d')}
                                className="bg-bg-dark border border-border-dark text-xs text-white rounded px-2 py-1 outline-none focus:border-primary"
                            >
                                <option value="24h">Last 24 Hours</option>
                                <option value="7d">Last 7 Days</option>
                            </select>
                         </div>
                         <div className="h-56 w-full">
                            <ResponsiveContainer width="100%" height="100%">
                                <BarChart data={chartData}>
                                    <Tooltip 
                                        cursor={{fill: 'rgba(255,255,255,0.05)'}}
                                        contentStyle={{ backgroundColor: '#101723', borderColor: '#2e3e5b', color: '#fff' }}
                                    />
                                    <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                                        {chartData.map((entry, index) => (
                                            <Cell key={`cell-${index}`} fill={chartView === '24h' && index === 6 ? '#3c83f6' : 'rgba(60, 131, 246, 0.4)'} />
                                        ))}
                                    </Bar>
                                    <XAxis dataKey="time" stroke="#566b8c" fontSize={12} tickLine={false} axisLine={false} />
                                </BarChart>
                            </ResponsiveContainer>
                         </div>
                    </section>

                    {/* Timeline */}
                    <section className="bg-surface-dark rounded-xl border border-border-dark p-6">
                         <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                             <Calendar className="text-primary" size={20} /> Availability Today
                         </h3>
                         <div className="flex gap-1 overflow-x-auto pb-2 scrollbar-hide">
                            {Array.from({ length: 12 }, (_, i) => i + 12).map((hour) => {
                                const isPast = hour < 15;
                                const isCurrent = hour === 15;
                                return (
                                    <div key={hour} className={`min-w-[70px] flex-1 flex flex-col gap-1 ${isCurrent ? 'opacity-100' : 'opacity-70'}`}>
                                        <div className={`h-10 rounded-lg flex items-center justify-center text-xs font-medium border ${
                                            isPast ? 'bg-surface-lighter border-border-dark text-white/30 cursor-not-allowed' :
                                            isCurrent ? 'bg-rose-500/20 border-rose-500 text-rose-400' :
                                            'bg-primary/20 border-primary/30 text-primary cursor-pointer hover:bg-primary/30'
                                        }`}>
                                            {hour}:00
                                        </div>
                                    </div>
                                )
                            })}
                         </div>
                         <div className="flex items-center gap-4 mt-3 text-xs text-text-secondary">
                             <div className="flex items-center gap-2"><span className="size-2.5 rounded bg-primary/20 border border-primary/30"></span> Available</div>
                             <div className="flex items-center gap-2"><span className="size-2.5 rounded bg-rose-500/20 border border-rose-500"></span> Occupied</div>
                             <div className="flex items-center gap-2"><span className="size-2.5 rounded bg-surface-lighter border border-border-dark"></span> Past</div>
                         </div>
                    </section>
                </div>

                {/* Right Column (4 cols) */}
                <div className="lg:col-span-4 flex flex-col gap-6">
                    {/* Map Mini */}
                    <div className="rounded-xl overflow-hidden border border-border-dark bg-surface-dark relative group h-48">
                         <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: "url('https://picsum.photos/seed/mapmini/400/300')" }}></div>
                         <div className="absolute inset-0 bg-gradient-to-t from-bg-dark to-transparent"></div>
                         <div className="absolute bottom-4 left-4 right-4 flex justify-between items-end">
                             <div>
                                 <p className="text-white font-bold text-sm">Navigation</p>
                                 <p className="text-text-secondary text-xs">2.4 km away • ~12 min drive</p>
                             </div>
                             <button className="bg-primary hover:bg-blue-600 text-white p-2 rounded-lg transition-colors shadow-lg">
                                 <ArrowRight size={18} />
                             </button>
                         </div>
                    </div>

                    {/* Booking Form */}
                    <div className="rounded-xl border border-border-dark bg-surface-dark p-6 flex flex-col gap-5 shadow-lg relative overflow-hidden">
                         {isBooked ? (
                            <div className="absolute inset-0 bg-surface-dark z-20 flex flex-col items-center justify-center text-center p-6 animate-in fade-in zoom-in">
                                <div className="size-16 rounded-full bg-emerald-500/20 flex items-center justify-center mb-4">
                                    <CheckCircle size={32} className="text-emerald-500" />
                                </div>
                                <h3 className="text-xl font-bold text-white mb-1">Confirmed!</h3>
                                <p className="text-text-secondary text-sm mb-6">Your spot has been reserved for {bookingTime}.</p>
                                <button 
                                    onClick={() => navigate('/')}
                                    className="w-full h-11 bg-surface-lighter hover:bg-border-dark border border-border-dark text-white rounded-lg font-bold text-sm transition-all"
                                >
                                    View Dashboard
                                </button>
                                <button 
                                    onClick={() => setIsBooked(false)}
                                    className="mt-3 text-xs text-text-secondary hover:text-white"
                                >
                                    Make another reservation
                                </button>
                            </div>
                         ) : null}

                         <div className="flex items-center gap-2 border-b border-border-dark pb-4">
                             <Clock className="text-primary" size={20} />
                             <h3 className="text-lg font-bold text-white">Reserve a Spot</h3>
                         </div>
                         
                         <div className="flex flex-col gap-1">
                             <label className="text-xs text-text-secondary font-medium uppercase tracking-wider">Start Time</label>
                             <input 
                                type="time" 
                                value={bookingTime}
                                onChange={(e) => setBookingTime(e.target.value)}
                                className="w-full bg-bg-dark border border-border-dark rounded-lg h-10 px-3 text-white text-sm focus:border-primary outline-none" 
                             />
                         </div>
                         
                         <div className="flex flex-col gap-2">
                             <label className="text-xs text-text-secondary font-medium uppercase tracking-wider">Duration</label>
                             <div className="grid grid-cols-3 gap-2">
                                 {['30m', '1h', '2h'].map(dur => (
                                    <button 
                                        key={dur}
                                        onClick={() => setSelectedDuration(dur)}
                                        className={`h-9 rounded border text-sm transition-all ${
                                            selectedDuration === dur 
                                            ? 'border-primary bg-primary/10 text-primary font-medium shadow-[0_0_10px_rgba(60,131,246,0.2)]' 
                                            : 'border-border-dark text-text-secondary hover:text-white hover:bg-surface-lighter'
                                        }`}
                                    >
                                        {dur}
                                    </button>
                                 ))}
                             </div>
                         </div>

                         <div className="bg-bg-dark rounded-lg p-3 flex justify-between items-center border border-border-dark mt-2">
                             <span className="text-sm text-text-secondary">Estimated Cost</span>
                             <span className="text-lg font-bold text-white">
                                {selectedDuration === '30m' ? '€7.50' : selectedDuration === '1h' ? '€14.50' : '€28.00'}
                             </span>
                         </div>

                         <button 
                            onClick={handleBooking}
                            disabled={isBooking}
                            className="w-full h-11 bg-primary hover:bg-blue-600 disabled:bg-primary/50 text-white rounded-lg font-bold text-sm shadow-lg shadow-blue-500/20 transition-all active:scale-[0.98] flex items-center justify-center gap-2"
                        >
                             {isBooking ? (
                                 <>
                                    <div className="size-4 rounded-full border-2 border-white/30 border-t-white animate-spin"></div>
                                    <span>Processing...</span>
                                 </>
                             ) : (
                                 <span>Confirm Reservation</span>
                             )}
                         </button>
                    </div>

                    {/* Specs */}
                    <div className="rounded-xl border border-border-dark bg-surface-dark p-5 flex flex-col gap-4">
                        <h4 className="text-white font-bold text-sm uppercase tracking-wide border-b border-border-dark pb-2">Technical Specs</h4>
                        <div className="flex items-center gap-3">
                            <div className="size-10 rounded-lg bg-bg-dark flex items-center justify-center border border-border-dark">
                                <Plug size={20} className="text-text-secondary" />
                            </div>
                            <div className="flex flex-col">
                                <span className="text-white text-sm font-medium">Type 2 (Mennekes)</span>
                                <span className="text-text-secondary text-xs">AC • Max 22kW</span>
                            </div>
                        </div>
                         <div className="flex items-center gap-3">
                            <div className="size-10 rounded-lg bg-bg-dark flex items-center justify-center border border-border-dark">
                                <Zap size={20} className="text-text-secondary" />
                            </div>
                            <div className="flex flex-col">
                                <span className="text-white text-sm font-medium">CCS2 Combo</span>
                                <span className="text-text-secondary text-xs">DC • Max 150kW</span>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </main>
    </div>
  );
};

export default StationDetails;
