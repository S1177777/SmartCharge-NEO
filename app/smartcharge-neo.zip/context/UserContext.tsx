import React, { createContext, useContext, useState } from 'react';

interface UserProfile {
  firstName: string;
  lastName: string;
  email: string;
  avatarUrl: string;
}

interface UserContextType {
  user: UserProfile;
  isAuthenticated: boolean;
  login: (email: string, name?: string) => void;
  logout: () => void;
  updateUser: (data: Partial<UserProfile>) => void;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export const UserProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Defaulting to true so the demo starts in the app, but logout works
  const [isAuthenticated, setIsAuthenticated] = useState(true);
  
  const [user, setUser] = useState<UserProfile>({
    firstName: 'Jean',
    lastName: 'Dupont',
    email: 'jean.dupont@example.com',
    avatarUrl: 'https://picsum.photos/200'
  });

  const login = (email: string, name?: string) => {
    setIsAuthenticated(true);
    if (name) {
        const [firstName, ...rest] = name.split(' ');
        setUser(prev => ({ 
            ...prev, 
            email, 
            firstName: firstName || prev.firstName, 
            lastName: rest.join(' ') || prev.lastName 
        }));
    } else {
        setUser(prev => ({ ...prev, email }));
    }
  };

  const logout = () => {
    setIsAuthenticated(false);
  };

  const updateUser = (data: Partial<UserProfile>) => {
    setUser(prev => ({ ...prev, ...data }));
  };

  return (
    <UserContext.Provider value={{ user, isAuthenticated, login, logout, updateUser }}>
      {children}
    </UserContext.Provider>
  );
};

export const useUser = () => {
  const context = useContext(UserContext);
  if (!context) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
};